package com.hair.HairSystem.mapper.groupPortrait;

import com.hair.HairSystem.pojo.groupPortrait.PortraitList;
import tk.mybatis.mapper.common.Mapper;

@org.apache.ibatis.annotations.Mapper
public interface PortraitListMapper extends Mapper<PortraitList> {

}
